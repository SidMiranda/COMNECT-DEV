SCoPE - Sistema Completo para Pagamento Eletr�nico.
Copyright (C) 1997,2000 Itautec Philco SA.
Todos os direitos reservados.

/********************************************************************/
		PROGRAMA EXEMPLO DO SCoPE PARA WINDOWS 32		
/********************************************************************/

Abaixo segue a descri��o de cada diret�rio:

.\Exemplo:	Exemplo da utiliza��o do SCoPE utilizando a ferramenta
		Microsoft Visual C++ 6.0 

.\libs:		Bibliotecas do SCoPE


Observa��o: 	O programa exemplo dever� ser executado no diret�rio onde 
		se encontram as suas deped�ncias, ou seja, as Dll's 
		do SCoPE. No caso a ScopeApi.dll, ScopePrf.dll e etc...
		